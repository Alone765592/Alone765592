# Rv's Paid Tata Play Bot

• Auto Fetch Channel Keys

• 7 Days Past TataPlay Rip

• 2gb Telegram Upload

• Gdrive Upload

• Custom Metadata

# Heroku Build Pack

```
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest.git
```
# Vps Commands
```
pip3 -r requirements.txt
```
```
sudo docker build . -t tata
```
```
sudo docker run tata
```

# Commands

```
/start - To Check Bot Alive or Not
/webdl - To Rip Tata Play 7 Days Past
```

# Webdl Command Examples

```
/webdl -c Disney -ss 06/07/2024+00:00:00 -to 06/07/2024+00:01:00 -title Doraemon
```

# Owner 
https://t.me/rv2006rv
